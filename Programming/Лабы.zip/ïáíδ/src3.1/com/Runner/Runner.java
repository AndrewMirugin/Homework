package com.Runner;

/*Определить класс Четырехугольник на плоскости, вершины которого
имеют тип Точка. Определить площадь и периметр четырехугольника.
Создать массив/список/множество объектов и подсчитать количество
четырехугольников разного типа (квадрат, прямоугольник, ромб, произвольный).
Определить для каждой группы наибольший и наименьший по площади (периметру) объект*/


import com.FourAngle.type;
import com.ListFourAngles.ListFourAngles;

import java.io.File;
import java.util.ArrayList;

public class Runner {
    public static void main(String[] args) {
        String filePath ="C:\\Users\\Андрей Миругин\\IdeaProjects\\FourthLaba\\src\\com\\ListFourAngles";
        File FourAngleListFile = new File(filePath,"ListFourAngles.txt");
        ListFourAngles listFA=new ListFourAngles(FourAngleListFile);
        System.out.print("Число квадратов: ");
        System.out.println(listFA.getNumberOf(type.Square));
        System.out.print("Число ромбов: ");
        System.out.println(listFA.getNumberOf(type.Rhombus));
        System.out.print("Число прямоугольников: ");
        System.out.println(listFA.getNumberOf(type.Rectangle));
        System.out.print("Число произвольных фигур: ");
        System.out.println(listFA.getNumberOf(type.Random));

        ArrayList<Integer> spis;
        spis=listFA.getAllIndexOfFigureByType(type.Rectangle);
        System.out.println("Максимальная площадь: "+listFA.getFourAnglesSpis().get(spis.get(findMaxSq(spis,listFA))));
        System.out.println("Минимальная площадь: "+listFA.getFourAnglesSpis().get(spis.get(findMinSq(spis,listFA))));
        System.out.println("Максимальный периметр: "+listFA.getFourAnglesSpis().get(spis.get(findMaxPer(spis,listFA))));
        System.out.println("Минимальный периметр: "+listFA.getFourAnglesSpis().get(spis.get(findMinPer(spis,listFA))));
    }
    private static int findMaxSq(ArrayList<Integer> spis, ListFourAngles listFA){
        int result=0;
        double max=listFA.getFourAnglesSpis().get(spis.get(0)).getSquare();
        for(int i=1;i<spis.size();i++){
            if(listFA.getFourAnglesSpis().get(spis.get(i)).getSquare()>max){
                max=listFA.getFourAnglesSpis().get(spis.get(i)).getSquare();
                result=i;
            }
        }
        return result;
    }

    private static int findMinSq(ArrayList<Integer> spis,ListFourAngles listFA){
        int result=0;
        double min=listFA.getFourAnglesSpis().get(spis.get(0)).getSquare();
        for(int i=1;i<spis.size();i++){
            if(listFA.getFourAnglesSpis().get(spis.get(i)).getSquare()<min){
                min=listFA.getFourAnglesSpis().get(spis.get(i)).getSquare();
                result=i;
            }
        }
        return result;
    }

    private static int findMaxPer(ArrayList<Integer> spis,ListFourAngles listFA){
        int result=0;
        double max=listFA.getFourAnglesSpis().get(spis.get(0)).getPerimeter();
        for(int i=1;i<spis.size();i++){
            if(listFA.getFourAnglesSpis().get(spis.get(i)).getPerimeter()>max){
                max=listFA.getFourAnglesSpis().get(spis.get(i)).getPerimeter();
                result=i;
            }
        }
        return result;
    }

    private static int findMinPer(ArrayList<Integer> spis,ListFourAngles listFA){
        int result=0;
        double min=listFA.getFourAnglesSpis().get(spis.get(0)).getPerimeter();
        for(int i=1;i<spis.size();i++){
            if(listFA.getFourAnglesSpis().get(spis.get(i)).getPerimeter()<min){
                min=listFA.getFourAnglesSpis().get(spis.get(i)).getPerimeter();
                result=i;
            }
        }
        return result;
    }
}
