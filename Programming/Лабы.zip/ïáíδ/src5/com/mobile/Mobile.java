package com.mobile;

public class Mobile {
    private String brand;
    private String model;
    private Characteristics characteristics;

    class Characteristics{
        private String processorModel;
        private int RAM;
        private int ROM;
        private double display;
        private String cameraSensor;
        private boolean isFingerprint;

        public Characteristics(String processorModel, int RAM, int ROM, double display, String cameraSensor, boolean isFingerprint) {
            setProcessorModel(processorModel);
            setROM(ROM);
            setRAM(RAM);
            setDisplay(display);
            setCameraSensor(cameraSensor);
            setFingerprint(isFingerprint);
        }

        public Characteristics() {
            setProcessorModel("unknown");
            setFingerprint(false);
            setCameraSensor("unknown");
            setDisplay(0.0);
            setRAM(0);
            setROM(0);
        }

        public String getProcessorModel() {
            return processorModel;
        }

        private void setProcessorModel(String processorModel) {
            this.processorModel = processorModel;
        }

        public int getRAM() {
            return RAM;
        }

        private void setRAM(int RAM) {
            this.RAM = RAM;
        }

        public int getROM() {
            return ROM;
        }

        private void setROM(int ROM) {
            this.ROM = ROM;
        }

        public double getDisplay() {
            return display;
        }

        private void setDisplay(double display) {
            this.display = display;
        }

        public String getCameraSensor() {
            return cameraSensor;
        }

        private void setCameraSensor(String cameraSensor) {
            this.cameraSensor = cameraSensor;
        }

        public boolean isFingerprint() {
            return isFingerprint;
        }

        @Override
        public String toString() {
            return "Characteristics{" +
                    "processorModel='" + getProcessorModel() + '\'' +
                    ", RAM=" + getRAM() +
                    ", ROM=" + getROM() +
                    ", display=" + getDisplay() +
                    ", cameraSensor='" + getCameraSensor() + '\'' +
                    ", isFingerprint=" + isFingerprint() +
                    '}';
        }

        private void setFingerprint(boolean fingerprint) {
            isFingerprint = fingerprint;
        }
    }

    public String getBrand() {
        return brand;
    }

    private void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    private void setModel(String model) {
        this.model = model;
    }

    public Mobile(String brand, String model,String processorModel, int RAM, int ROM, double display, String cameraSensor, boolean isFingerprint) {
        setCharacteristics(processorModel,RAM,ROM,display,cameraSensor,isFingerprint);
        setModel(model);
        setBrand(brand);
    }

    public Characteristics getCharacteristics() {
        return characteristics;
    }

    private void setCharacteristics(String processorModel, int RAM, int ROM, double display, String cameraSensor, boolean isFingerprint) {
        characteristics = new Characteristics(processorModel,RAM,ROM,display,cameraSensor,isFingerprint);
    }

    public Mobile() {
        setBrand("unknown");
        setModel("unknown");
        characteristics= new Characteristics();
    }

    @Override
    public String toString() {
        return "Mobile{" +
                "brand='" + getBrand() + '\'' +
                ", model='" + getModel() + '\'' +
                ", " + getCharacteristics().toString() + '\'' +
                '}';
    }
}

