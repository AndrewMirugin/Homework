package com.comedy;

import com.ourFilm.OurFilmImpl;

public class Comedy extends OurFilmImpl {
    private boolean isFunny;

    public boolean isFunny() {
        return isFunny;
    }

    public void setFunny(boolean funny) {
        isFunny = funny;
    }

    public Comedy(boolean isFunny) {
        super("Комедия");
        setFunny(isFunny);
    }

    public Comedy(int releaseYear, String author, String name,  boolean isFunny) {
        super(releaseYear, author, name, "Комедия");
        setFunny(isFunny);
    }

    @Override
    public String toString() {
        return "Comedy{" +
                "releaseYear=" + getReleaseYear() +
                ", author='" + getAuthor() + '\'' +
                ", name='" + getName() + '\'' +
                ", genre='" + getGenre() + '\'' +
                ", isFunny=" + isFunny +
                '}';
    }
}
