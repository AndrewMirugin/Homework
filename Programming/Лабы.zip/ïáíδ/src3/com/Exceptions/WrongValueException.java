package com.Exceptions;

public class WrongValueException extends Exception {

}
