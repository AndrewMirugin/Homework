package com.ListFourAngles;

import com.FourAngle.FourAngle;
import com.FourAngle.type;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;



public class ListFourAngles {
    private ArrayList<FourAngle> fourAnglesSpis = new ArrayList<>();
    public ListFourAngles(File ListFourAnglesFile) {
        String oneLine;
        if(ListFourAnglesFile.exists()){
            Scanner scanner= null;
            try {
                if(!ListFourAnglesFile.exists()){
                    throw new FileNotFoundException();
                }
                scanner = new Scanner(ListFourAnglesFile);
                while(scanner.hasNext()){
                    oneLine = scanner.nextLine();
                    if(Validation(oneLine)){
                        Scanner scan = new Scanner(oneLine);
                        fourAnglesSpis.add(new FourAngle(scan.nextInt(),scan.nextInt(),scan.nextInt(),scan.nextInt(),scan.nextInt(),scan.nextInt(),scan.nextInt(),scan.nextInt()));
                    }
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();

            }
        }
    }

    public ArrayList<FourAngle> getFourAnglesSpis() {
        return fourAnglesSpis;
    }

    public int getNumberOf(type ft){
        int result=0;
        for(int i=0;i < getFourAnglesSpis().size();i++){
            if(getFourAnglesSpis().get(i).getType()== ft){
                result++;
            }
        }

        return result;
    }

    public ArrayList<Integer> getAllIndexOfFigureByType(type ft){
        ArrayList<Integer> spis=new ArrayList<>();
        for(int i=0;i < getFourAnglesSpis().size();i++){
            if(getFourAnglesSpis().get(i).getType()== ft){
                spis.add(i);
            }
        }
        return spis;
    }

    private boolean Validation(String str){
        Scanner scanner=new Scanner(str);
        int i=0;
        while(scanner.hasNextInt()){
            scanner.next();
            i++;
        }
        return i==8;
    }
}
