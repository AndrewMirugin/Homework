package com.FourAngle;

public enum type {Square,Rectangle,Rhombus,Random}
