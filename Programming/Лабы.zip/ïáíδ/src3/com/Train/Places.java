package com.Train;

public class Places {
    private int all;
    private int compartment;
    private int reservedSeat;
    private int suit;

    public Places(int compartment, int reservedSeat, int suit) {
        setCompartment(compartment);
        setReservedSeat(reservedSeat);
        setSuit(suit);
        all=getCompartment()+getReservedSeat()+getSuit();
    }

    public Places() {
        all=0;
        compartment=0;
        reservedSeat=0;
        suit=0;
    }

    public int getCompartment() {
        return compartment;
    }

    public void setCompartment(int compartment) {
        this.compartment = Validation(compartment);
        setAll();
    }

    public int getReservedSeat() {
        return reservedSeat;
    }

    public void setReservedSeat(int reservedSeat) {
        this.reservedSeat = Validation(reservedSeat);
        setAll();
    }

    public int getSuit() {
        return suit;
    }

    public void setSuit(int suit) {
        this.suit = Validation(suit);
        setAll();
    }

    public int getAll(){ return all; }

    private void setAll(){
        all=getCompartment()+getReservedSeat()+getSuit();
    }

    public void setAllValues(int suit, int reservedSeat, int compartment){
        setSuit(suit);
        setReservedSeat(reservedSeat);
        setCompartment(compartment);
        setAll();
    }

    private int Validation(int param){
        try{
            if(param<0) {
                throw new IllegalArgumentException("Неправильно задано количество мест!");
            }
        }
        catch(IllegalArgumentException e){
            param=0;
            System.out.println(e);
        }
        return param;


    }

    @Override
    public String toString() {
        return "Places{" +
                "all=" + all +
                ", compartment=" + compartment +
                ", reservedSeat=" + reservedSeat +
                ", suit=" + suit +
                '}';
    }
}
