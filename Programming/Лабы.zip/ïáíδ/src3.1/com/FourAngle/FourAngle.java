package com.FourAngle;

import com.Dot.Dot;

public class FourAngle {
   private Dot a;
   private Dot b;
   private Dot c;
   private Dot d;
   private double AB;
   private double BC;
   private double CD;
   private double DA;
   private type FourAngleType;

    public double getAB() {
        return AB;
    }

    private void setAB() {
        AB=getSideLength(getA(),getB());
    }

    public double getBC() {
        return BC;
    }

    private void setBC() {
        BC = getSideLength(getB(),getC());
    }

    public double getCD() {
        return CD;
    }

    private void setCD() {
        CD  = getSideLength(getC(),getD());
    }

    public double getDA() {
        return DA;
    }

    private void setDA() {
        DA = getSideLength(getD(),getA());
    }

    public FourAngle(Dot a, Dot b, Dot c, Dot d) {
        setA(a);
        setB(b);
        setC(c);
        setD(d);
        setAB();
        setBC();
        setCD();
        setDA();
        setType();
    }

    public FourAngle(int x1, int y1,int x2, int y2,int x3, int y3,int x4, int y4){
        setA(x1,y1);
        setB(x2,y2);
        setC(x3,y3);
        setD(x4,y4);
        setAB();
        setBC();
        setCD();
        setDA();
        setType();
    }

    public Dot getA() {
        return a;
    }

    private void setA(Dot a) {
        this.a = a;
    }

    private void setA(int first,int second){
        a=new Dot(first,second);
    }

    public Dot getB() {
        return b;
    }

    private void setB(Dot b) {
        this.b = b;
    }

    private void setB(int first,int second){
        b=new Dot(first,second);
    }

    public Dot getC() {
        return c;
    }

    private void setC(Dot c) {
        this.c = c;
    }

    private void setC(int first,int second){
        c=new Dot(first,second);
    }

    public Dot getD() {
        return d;
    }

    private void setD(Dot d) {
        this.d = d;
    }

    private void setD(int first,int second){
        d=new Dot(first,second);
    }

    private double getSideLength(Dot x, Dot y){
        return Math.sqrt((y.getX()-x.getX())*(y.getX()-x.getX())+(y.getY()-x.getY())*(y.getY()-x.getY()));
    }

    public double getSquare(){
        double p=(AB+BC+CD+DA)/2;
        return Math.sqrt((p-AB)*(p-BC)*(p-CD)*(p-DA));
    }

    public double getPerimeter(){
        return AB+BC+CD+DA;
    }

    private void setType() {
        type result;
        if (getAB() == getBC() && getBC() == getCD() && getCD() == getDA()) {
            if ((getB().getX()-getA().getX())*(getC().getX()-getB().getX())+(getB().getY()-getA().getY())*(getC().getY()-getB().getY())==0) {//Скалярное произведение
                result = type.Square;
            } else {
                result = type.Rhombus;
            }
        } else {
            if (getSquare() == getAB() * getBC() && getSquare() == getBC() * getCD() && getSquare() == getCD() * getDA() && getSquare() == getDA() * getAB()) {//проверка на равенство площадей по разным формулам
                result = type.Rectangle;
            } else {
                result = type.Random;
            }
        }
        FourAngleType=result;
    }

    public type getType(){
        return FourAngleType;
    }

    @Override
    public String toString() {
        return "FourAngle{" +
                "A=" + getA().toString() +
                ", B=" + getB().toString() +
                ", C=" + getC().toString() +
                ", D=" + getD().toString() +
                ", AB=" + getAB() +
                ", BC=" + getBC() +
                ", CD=" + getCD() +
                ", DA=" + getDA() +
                ", FourAngleType=" + FourAngleType.toString() +
                ", Square=" + getSquare()+
                ", Perimeter=" + getPerimeter()+
                '}';
    }
}
