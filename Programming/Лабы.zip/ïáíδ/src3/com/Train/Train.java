package com.Train;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Train {
    private String destination;
    private int trainNumber;
    private String timeStart;
    private Places place;

    public Train() {
        setTrainNumber(0);
        setTimeStart("");
        setDestination("");
        this.place = new Places(0,0,0);
    }

    public Train(String destination, int trainNumber, String timeStart, int compartment, int reservedSeat, int suit) {
        setDestination(destination);
        setTimeStart(timeStart);
        setTrainNumber(trainNumber);
        this.place = new Places(compartment,reservedSeat,suit);
    }

    public Train(String data) {
        Scanner scanner = new Scanner(data);
        String destination;
        int trainNumber;
        String timeStart;
        try{
            if(!scanner.hasNext()){
                throw new NullPointerException("Отсутствуют данные");
            }
        }
        catch (NullPointerException e) {
            e.printStackTrace();
        }
        try
        {
            if(!scanner.hasNext()){
                throw new NullPointerException("Неправильный пункт назначения");
            }
            destination=scanner.next();
        }
        catch (NullPointerException e){
            e.printStackTrace();
            destination="";
        }
        setDestination(destination);
        try
        {
            if(!scanner.hasNext()){
                throw new NullPointerException("Неправильный номер поезда");
            }
            trainNumber=scanner.nextInt();
        }
        catch (NullPointerException e){
            e.printStackTrace();
            trainNumber=0;
        }
        setTrainNumber(trainNumber);
        try
        {
            if(!scanner.hasNext()){
                throw new NullPointerException("Неправильное время");
            }
            timeStart=scanner.next();
        }
        catch (NullPointerException e){
            e.printStackTrace();
            timeStart="00:00";
        }
        setTimeStart(timeStart);
        int compartment;
        int reservedSeat;
        int suit;
        try
        {
            if(!scanner.hasNextInt()){
                throw new NullPointerException("Неверное число купе");
            }
            compartment=scanner.nextInt();


        }
        catch (NullPointerException e){
            e.printStackTrace();
            compartment=0;
        }
        try
        {
            if(!scanner.hasNextInt()){
                throw new NullPointerException("Неверное число плацкарта");
            }
            reservedSeat=scanner.nextInt();
        }
        catch (NullPointerException e){
            e.printStackTrace();
            reservedSeat=0;
        }

        try
        {
            if(!scanner.hasNextInt() || !scanner.hasNext()){
                throw new NullPointerException("Неверное число мест люкс");
            }
            suit=scanner.nextInt();
        }
        catch (NullPointerException e){
            suit=0;
            e.printStackTrace();

        }
        place = new Places(compartment,reservedSeat,suit);
    }

    public String getDestination() {
        return destination;
    }

    public int getTrainNumber() {
        return trainNumber;
    }

    public String getTimeStart() {
        return timeStart;
    }

    public Places getPlace() {
        return place;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public void setTrainNumber(int trainNumber) {
        try{
            if(trainNumber<0) {
                throw new IllegalArgumentException("Нельзя присвоить отрицательные значения номеру!");
            }
        }
        catch(IllegalArgumentException e){
            trainNumber=0;
            e.printStackTrace();
        }
        this.trainNumber = trainNumber;
    }

    public void setTimeStart(String timeStart) {
        Pattern regExp=Pattern.compile("([0-1][0-9]|[2][0-3])[.,/#:][0-5][0-9]");
        Matcher matcher = regExp.matcher(timeStart);
        try{
            if(!matcher.matches()){
                throw new IllegalArgumentException("Неправильный формат времени");
            }
            this.timeStart = timeStart;
        }
        catch (IllegalArgumentException e) {
            this.timeStart = "00:00";
            e.printStackTrace();
        }
    }

    public void showDestination() {
        System.out.println(getDestination());
    }

    public void showTrainNumber(){
        System.out.println(getTrainNumber());
    }

    public void showTimeStart(){
        System.out.println(getTimeStart());
    }

    public void showPlaces(){
        System.out.println(place.toString());
    }

    @Override
    public String toString() {
        return "Train{" +
                "destination='" + getDestination() + '\'' +
                ", trainNumber=" + getTrainNumber() +
                ", timeStart='" + getTimeStart() + '\'' +
                ", places: " +
                " compartment=" +place.getCompartment() +
                ", suit=" +place.getSuit() +
                ", reserved seat=" +place.getReservedSeat() +
                ", all=" +place.getAll()+
                '}';
    }
}
