package com.ourFilm;

import com.film.IFilm;

import java.util.Scanner;

public class OurFilmImpl implements IFilm {
    private int releaseYear;
    private String author;
    private String name;
    private String genre;

    public OurFilmImpl() {
        setReleaseYear(1000);
        setAuthor("Unknown");
        setName("Unknown");
        setGenre("Unknown");
    }

    public OurFilmImpl(String genre){
        setReleaseYear(1000);
        setAuthor("Unknown");
        setName("Unknown");
        setGenre(genre);
    }

    public OurFilmImpl(int releaseYear, String author, String name, String genre) {
        setAuthor(author);
        setGenre(genre);
        setName(name);
        setReleaseYear(releaseYear);
    }

    public int getReleaseYear() {
        return releaseYear;
    }

    private void setReleaseYear(int releaseYear) {
        this.releaseYear = releaseYear;
    }

    public String getAuthor() {
        return author;
    }

    private void setAuthor(String author) {
        this.author = author;
    }

    public String getName() {
        return name;
    }

    private void setName(String name) {
        this.name = name;
    }

    public String getGenre() {
        return genre;
    }

    private void setGenre(String genre) {
        this.genre = genre;
    }

    @Override
    public void watch() {
        System.out.println("Start watching");
    }

    @Override
    public void rate() {
        int rating;
        Scanner scan = new Scanner(System.in);
        System.out.println("Please, leave your rate here: ");
        rating= scan.nextInt();
        if(rating>0 && rating <=10) {
            System.out.println("Your rate is: "+rating);
        }
        else{
            System.out.println("There are some mistakes while rating the film :( ");
        }
    }

    @Override
    public void leftComment() {
        String comment;
        Scanner scan = new Scanner(System.in);
        System.out.println("Please, leave your comment here: ");
        comment = scan.nextLine();
        System.out.println("Your comment is: "+comment);

    }

    @Override
    public String toString() {
        return "OurFilmImpl{" +
                "releaseYear=" + releaseYear +
                ", author='" + author + '\'' +
                ", name='" + name + '\'' +
                ", genre='" + genre + '\'' +
                '}';
    }
}
