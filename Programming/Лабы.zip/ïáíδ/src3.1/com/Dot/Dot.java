package com.Dot;

public class Dot {
    private int x;
    private int y;

    public Dot(int x, int y) {
        setX(x);
        setY(y);
    }

    public int getX() {
        return x;
    }

    private void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    private void setY(int y) {
        this.y = y;
    }

    public boolean equals(Dot second){
        return x==second.getX() && y==second.getY();
    }

    @Override
    public String toString() {
        return "("+getX()+", "+getY()+")";
    }
}
