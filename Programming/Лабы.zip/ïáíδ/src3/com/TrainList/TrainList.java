package com.TrainList;

import com.Train.Train;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

public class TrainList {
   private ArrayList<Train> trainList=new ArrayList<>();
   private int length=0;
   public TrainList(File trainListFile) {
       if(trainListFile.exists()){
           Scanner scanner= null;
           try {
               if(!trainListFile.exists()){
                   throw new FileNotFoundException();
               }
               scanner = new Scanner(trainListFile);
               while(scanner.hasNext()){
                   String oneLine = scanner.nextLine();
                   trainList.add(new Train(oneLine));
                   length++;
               }
           } catch (FileNotFoundException e) {
               e.printStackTrace();

           }
       }
   }
   public int getLength(){
       return trainList.size();
   }
   public ArrayList<Train> getTrainList() {
        return trainList;
    }

   public Train getTrain(int index){ return trainList.get(index);}
}
