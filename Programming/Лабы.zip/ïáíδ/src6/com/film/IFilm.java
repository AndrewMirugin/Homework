package com.film;

public interface IFilm {
   void watch();
   void rate();
   void leftComment();
}
