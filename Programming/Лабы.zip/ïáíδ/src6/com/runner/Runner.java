package com.runner;

import com.comedy.Comedy;

class Runner {

    public static void main(String[] args) {

        Comedy com = new Comedy(true);
        System.out.println(com.toString());
    }
}
