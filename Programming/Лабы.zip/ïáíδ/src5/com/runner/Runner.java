package com.runner;

import com.mobile.Mobile;

public class Runner {
    public static void main(String[] args) {
        Mobile mobile = new Mobile();
        Mobile mobile1 = new Mobile("Xiaomi","Mi5s","Snapdragon 821",4,32,5.2,"Sony IMX376",true);

        System.out.println(mobile.toString());
        System.out.println(mobile1.toString());

    }
}
