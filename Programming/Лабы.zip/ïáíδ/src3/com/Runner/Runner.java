package com.Runner;

import com.TrainList.TrainList;
import java.io.File;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/*Train: Пункт назначения, Номер поезда, Время отправления,
 *Число мест (общих, купе, плацкарт, люкс). Создать массив объектов. Вывести:
 *a) список поездов, следующих до заданного пункта назначения;
 *b) список поездов, следующих до заданного пункта назначения и
 *отправляющихся после заданного часа;
 *c) список поездов, отправляющихся до заданного пункта назначения и имеющих общие места.*/


public class Runner {
    public static void main(String[] args) {
        String filePath ="C:\\Users\\Андрей Миругин\\IdeaProjects\\ThirdLaba\\src\\com\\TrainList";
        File trainListFile = new File(filePath,"TrainList.txt");
        System.out.println(trainListFile.exists());
        TrainList trainList=new TrainList(trainListFile);
        Scanner scanner = new Scanner(System.in);
        //a)
        System.out.println("Enter destination:");
        String destination=scanner.next();
        for(int i=0;i<trainList.getLength();i++){
            if(destination.equals(trainList.getTrain(i).getDestination())){
                System.out.println(trainList.getTrain(i).toString());
            }
        }
        //b)
        System.out.println("Enter destination:");
        destination=scanner.next();
        System.out.println("Enter time:");
        String time=scanner.next();
        Pattern regExp=Pattern.compile("([0-1]//d|[2][0-3])[.,/#:][0-5][0-9]");
        Matcher matcher = regExp.matcher(time);
        try{
            if(!matcher.matches()){
                throw new IllegalArgumentException("Неправильный формат времени");
            }
        }
        catch (IllegalArgumentException e) {
            time = "00:00";
            e.printStackTrace();
        }
        for(int i=0;i<trainList.getLength();i++){
            if(time.equals(trainList.getTrain(i).getTimeStart())){
                System.out.println(trainList.getTrain(i).toString());
            }
        }

        System.out.println("Enter destination:");
        destination=scanner.next();
        for(int i=0;i<trainList.getLength();i++){
            if(destination.equals(trainList.getTrain(i).getDestination()) && trainList.getTrain(i).getPlace().getAll()>0){
                System.out.println(trainList.getTrain(i).toString());
            }
        }
    }
}
